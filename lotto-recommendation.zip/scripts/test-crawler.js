import fetch from "node-fetch"
import { JSDOM } from "jsdom"

// 동행복권 사이트에서 최신 회차 정보 가져오기
async function getLatestLottoRound() {
  try {
    console.log("최신 회차 정보 가져오기 시작...")

    const response = await fetch("https://www.dhlottery.co.kr/common.do?method=main", {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    const html = await response.text()
    const dom = new JSDOM(html)
    const document = dom.window.document

    // 회차 정보 추출 (여러 방법 시도)
    let roundText = null

    // 방법 1: 정규식
    const roundMatch = html.match(/<strong>(\d+)회<\/strong>/)
    if (roundMatch && roundMatch[1]) {
      roundText = roundMatch[1]
      console.log(`정규식으로 찾은 회차: ${roundText}`)
    }

    // 방법 2: DOM 파싱
    const roundElement = document.querySelector(".win_result strong")
    if (roundElement) {
      const text = roundElement.textContent
      const match = text.match(/(\d+)/)
      if (match) {
        console.log(`DOM으로 찾은 회차: ${match[1]}`)
        if (!roundText) roundText = match[1]
      }
    }

    if (roundText) {
      const round = Number.parseInt(roundText, 10)
      console.log(`최신 회차: ${round}`)
      return round
    }

    console.log("회차 정보를 찾을 수 없습니다. 기본값 반환")
    return 1171 // 현재 최신 회차로 업데이트
  } catch (error) {
    console.error("최신 회차 정보 가져오기 실패:", error)
    return 1171 // 현재 최신 회차로 업데이트
  }
}

// 특정 회차의 당첨 번호 가져오기
async function fetchLottoDataFromDonghaeng(round) {
  try {
    console.log(`${round}회차 당첨 번호 가져오기...`)

    const url = `https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=${round}`
    const response = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    const data = await response.json()

    if (data.returnValue !== "success") {
      throw new Error(`${round}회차 데이터 가져오기 실패`)
    }

    const numbers = [data.drwtNo1, data.drwtNo2, data.drwtNo3, data.drwtNo4, data.drwtNo5, data.drwtNo6].sort(
      (a, b) => a - b,
    )

    console.log(`${round}회차 당첨 번호: ${numbers.join(", ")}`)
    return numbers
  } catch (error) {
    console.error(`${round}회차 당첨 번호 가져오기 실패:`, error)
    throw error
  }
}

// 여러 회차의 당첨 번호 가져오기
async function scrapeLatestLottoData(rounds = 5) {
  try {
    console.log(`최근 ${rounds}회차 데이터 가져오기 시작...`)

    // 최신 회차 번호 가져오기
    const latestRound = await getLatestLottoRound()
    console.log(`최신 회차: ${latestRound}`)

    // 지정된 회차 수만큼 데이터 가져오기
    const lottoData = []

    for (let i = 0; i < rounds; i++) {
      const roundNumber = latestRound - i
      if (roundNumber <= 0) break

      try {
        const numbers = await fetchLottoDataFromDonghaeng(roundNumber)
        lottoData.push(numbers)
        console.log(`${roundNumber}회차 데이터 추가 완료`)
      } catch (error) {
        console.error(`${roundNumber}회차 데이터 가져오기 실패, 다음 회차로 진행`)
      }

      // API 요청 간 간격 두기
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }

    console.log(`총 ${lottoData.length}개 회차 데이터 수집 완료`)
    return lottoData
  } catch (error) {
    console.error("로또 데이터 스크래핑 중 오류 발생:", error)
    throw error
  }
}

// 메인 함수
async function main() {
  console.log("로또 데이터 크롤러 테스트 시작")

  try {
    const lottoData = await scrapeLatestLottoData(5)
    console.log("수집된 데이터:")
    console.log(JSON.stringify(lottoData, null, 2))
  } catch (error) {
    console.error("테스트 실패:", error)
  }

  console.log("테스트 완료")
}

main()
