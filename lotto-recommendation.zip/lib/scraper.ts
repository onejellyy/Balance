// 동행복권 사이트에서 당첨 번호 데이터를 스크래핑하는 함수
export async function scrapeLatestLottoData(rounds = 100): Promise<number[][]> {
  try {
    // 최신 회차 번호 가져오기
    const latestRound = await getLatestLottoRound()
    console.log(`최신 회차: ${latestRound}`)

    // 지정된 회차 수만큼 데이터 가져오기
    const lottoData: number[][] = []

    // 가져올 회차 수 제한 (너무 많은 요청을 방지)
    const roundsToFetch = Math.min(rounds, latestRound)

    for (let i = 0; i < roundsToFetch; i++) {
      const roundNumber = latestRound - i
      if (roundNumber <= 0) break

      try {
        console.log(`${roundNumber}회차 데이터 가져오는 중...`)
        const numbers = await fetchLottoDataFromDonghaeng(roundNumber)
        lottoData.push(numbers)

        // API 요청 간 간격 두기 (서버 부하 방지)
        if (i < roundsToFetch - 1) {
          await new Promise((resolve) => setTimeout(resolve, 300))
        }
      } catch (error) {
        console.error(`${roundNumber}회차 데이터 가져오기 실패:`, error)
        // 오류가 발생해도 계속 진행
      }
    }

    console.log(`총 ${lottoData.length}개 회차 데이터 수집 완료`)

    // 데이터가 없는 경우 목업 데이터 반환
    if (lottoData.length === 0) {
      console.log("수집된 데이터가 없어 목업 데이터 반환")
      return getMockLottoData(rounds)
    }

    return lottoData
  } catch (error) {
    console.error("로또 데이터 스크래핑 중 오류 발생:", error)
    // 오류 발생 시 목업 데이터 반환
    return getMockLottoData(rounds)
  }
}

// 최신 회차 번호 가져오기
async function getLatestLottoRound(): Promise<number> {
  try {
    // 동행복권 메인 페이지에서 최신 회차 정보 가져오기
    const response = await fetch("https://www.dhlottery.co.kr/common.do?method=main", {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    const html = await response.text()

    // 정규식을 사용하여 최신 회차 번호 추출
    // 예: <strong>1079회</strong> 형태의 텍스트에서 1079 추출
    const roundMatch = html.match(/<strong>(\d+)회<\/strong>/)
    if (roundMatch && roundMatch[1]) {
      return Number.parseInt(roundMatch[1], 10)
    }

    // 기본값 반환 (추출 실패 시)
    console.log("최신 회차 정보를 찾을 수 없어 기본값 반환")
    return 1171 // 현재 최신 회차로 업데이트
  } catch (error) {
    console.error("최신 회차 정보 가져오기 실패:", error)
    return 1171 // 현재 최신 회차로 업데이트
  }
}

// 동행복권 API에서 특정 회차의 당첨 번호 가져오기
async function fetchLottoDataFromDonghaeng(round: number): Promise<number[]> {
  const url = `https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=${round}`

  const response = await fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    },
  })

  const data = await response.json()

  if (data.returnValue !== "success") {
    throw new Error(`Failed to fetch data for round ${round}`)
  }

  return [data.drwtNo1, data.drwtNo2, data.drwtNo3, data.drwtNo4, data.drwtNo5, data.drwtNo6].sort((a, b) => a - b)
}

// 테스트용 목업 데이터 (API 호출 실패 시 사용)
function getMockLottoData(rounds: number): number[][] {
  const mockData: number[][] = []

  // 예시 데이터 생성
  for (let i = 0; i < rounds; i++) {
    const drawNumbers: number[] = []
    while (drawNumbers.length < 6) {
      const num = Math.floor(Math.random() * 45) + 1
      if (!drawNumbers.includes(num)) {
        drawNumbers.push(num)
      }
    }
    mockData.push(drawNumbers.sort((a, b) => a - b))
  }

  return mockData
}
