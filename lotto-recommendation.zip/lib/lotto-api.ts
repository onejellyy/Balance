// 동행복권 API를 사용하여 로또 데이터를 가져오는 함수들

// 특정 회차의 당첨 번호 가져오기
export async function fetchLottoRound(round: number): Promise<LottoRound | null> {
  try {
    // 안전한 최대 회차 제한 (현재 알려진 최신 회차)
    const SAFE_MAX_ROUND = 1171

    // 요청 회차가 안전한 최대 회차를 초과하면 null 반환
    if (round > SAFE_MAX_ROUND) {
      console.log(`${round}회차는 현재 안전한 최대 회차(${SAFE_MAX_ROUND})를 초과합니다.`)
      return null
    }

    const url = `https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=${round}`
    const response = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
      next: { revalidate: 86400 }, // 24시간 캐싱
    })

    const data = await response.json()

    if (data.returnValue !== "success") {
      console.error(`${round}회차 데이터 가져오기 실패: API 응답이 success가 아님`)
      return null
    }

    // 당첨 번호 추출 및 정렬
    const winningNumbers = [data.drwtNo1, data.drwtNo2, data.drwtNo3, data.drwtNo4, data.drwtNo5, data.drwtNo6].sort(
      (a, b) => a - b,
    )

    const bonusNumber = data.bnusNo
    const drawDate = new Date(data.drwNoDate)

    return {
      round,
      numbers: winningNumbers,
      bonusNumber,
      drawDate,
      totalSellAmount: data.totSellamnt,
      firstWinnerCount: data.firstPrzwnerCo,
      firstPrizeAmount: data.firstWinamnt,
    }
  } catch (error) {
    console.error(`${round}회차 데이터 가져오기 실패:`, error)
    return null
  }
}

// 최신 회차 번호 가져오기 (안정적인 방법으로 개선)
export async function getLatestLottoRound(): Promise<number> {
  // 현재 알려진 최신 회차 (안전한 기본값)
  const KNOWN_LATEST_ROUND = 1171
  return KNOWN_LATEST_ROUND
}

// 여러 회차의 데이터 가져오기 (범위 지정)
export async function fetchLottoDataRange(startRound: number, endRound: number): Promise<LottoRound[]> {
  const results: LottoRound[] = []
  const SAFE_MAX_ROUND = 1171

  // 안전한 범위로 제한
  const safeEndRound = Math.min(endRound, SAFE_MAX_ROUND)

  // 너무 많은 요청을 방지하기 위한 제한
  const maxRequestsAtOnce = 5

  // 회차 범위를 청크로 나누기
  for (let i = startRound; i <= safeEndRound; i += maxRequestsAtOnce) {
    const chunk = []
    const chunkEnd = Math.min(i + maxRequestsAtOnce - 1, safeEndRound)

    console.log(`${i}회차부터 ${chunkEnd}회차까지 데이터 가져오는 중...`)

    // 각 청크 내에서 병렬로 요청 처리
    const promises = []
    for (let round = i; round <= chunkEnd; round++) {
      promises.push(fetchLottoRound(round))
    }

    const chunkResults = await Promise.all(promises)

    // null이 아닌 결과만 추가
    for (const result of chunkResults) {
      if (result) {
        results.push(result)
      }
    }

    // API 요청 간 간격 두기 (서버 부하 방지)
    if (chunkEnd < safeEndRound) {
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }
  }

  return results.sort((a, b) => b.round - a.round) // 최신 회차부터 정렬
}

// 최신 회차부터 지정된 개수만큼의 데이터 가져오기 (기본값: 100개)
export async function fetchLimitedLottoData(count = 100): Promise<LottoRound[]> {
  try {
    const latestRound = await getLatestLottoRound()
    console.log(`최신 회차: ${latestRound}`)

    // 시작 회차 계산 (최신 회차 - count + 1, 최소값은 1)
    const startRound = Math.max(1, latestRound - count + 1)
    console.log(`${startRound}회차부터 ${latestRound}회차까지 데이터 가져오기 시작`)

    return await fetchLottoDataRange(startRound, latestRound)
  } catch (error) {
    console.error("로또 데이터 가져오기 실패:", error)
    return []
  }
}

// 최신 회차 데이터만 가져오기
export async function fetchLatestLottoData(): Promise<LottoRound | null> {
  try {
    const latestRound = await getLatestLottoRound()
    return await fetchLottoRound(latestRound)
  } catch (error) {
    console.error("최신 회차 데이터 가져오기 실패:", error)
    return null
  }
}

// 로또 회차 데이터 타입 정의
export interface LottoRound {
  round: number
  numbers: number[]
  bonusNumber: number
  drawDate: Date
  totalSellAmount?: number
  firstWinnerCount?: number
  firstPrizeAmount?: number
}
