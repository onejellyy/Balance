import { cache } from "react"
import { fetchLimitedLottoData, fetchLatestLottoData, type LottoRound } from "./lotto-api"

interface LottoRecommendation {
  hotNumbers: number[]
  coldNumbers: number[]
  lastUpdated: string
  dataCount: number
  latestRound: LottoRound | null
  hotMatches: number
  coldMatches: number
}

// 캐시된 로또 추천 함수 (개선된 버전)
export const getLottoRecommendationsEnhanced = cache(async (): Promise<LottoRecommendation> => {
  try {
    console.log("로또 데이터 분석 시작...")

    // 최신 회차 데이터 가져오기
    const latestRound = await fetchLatestLottoData()

    // 최신 회차부터 100개 회차만 가져오기
    const lottoData = await fetchLimitedLottoData(100)

    // 데이터가 없는 경우 기본값 반환
    if (!lottoData || lottoData.length === 0) {
      console.log("데이터를 가져오지 못했습니다. 기본값 반환")
      return {
        ...getDefaultRecommendation(),
        latestRound: null,
        hotMatches: 0,
        coldMatches: 0,
      }
    }

    // 번호만 추출
    const numbersData = lottoData.map((round) => round.numbers)

    // 번호 빈도수 계산
    const frequencyMap = calculateNumberFrequency(numbersData)

    // 빈도수에 따라 정렬
    const sortedByFrequency = Object.entries(frequencyMap)
      .sort((a, b) => b[1] - a[1])
      .map((entry) => Number.parseInt(entry[0]))

    // 가장 많이 나온 번호 6개 (HOT)
    const hotNumbers = sortedByFrequency.slice(0, 6).sort((a, b) => a - b)

    // 가장 적게 나온 번호 6개 (COLD)
    const coldNumbers = sortedByFrequency.slice(-6).sort((a, b) => a - b)

    console.log("로또 데이터 분석 완료")
    console.log("HOT 번호:", hotNumbers)
    console.log("COLD 번호:", coldNumbers)

    // 최신 회차와 HOT/COLD 번호 일치 여부 계산
    let hotMatches = 0
    let coldMatches = 0

    if (latestRound) {
      hotMatches = countMatches(latestRound.numbers, hotNumbers)
      coldMatches = countMatches(latestRound.numbers, coldNumbers)
    }

    return {
      hotNumbers,
      coldNumbers,
      lastUpdated: new Date().toISOString(),
      dataCount: lottoData.length,
      latestRound,
      hotMatches,
      coldMatches,
    }
  } catch (error) {
    console.error("로또 데이터 처리 중 오류 발생:", error)
    return {
      ...getDefaultRecommendation(),
      latestRound: null,
      hotMatches: 0,
      coldMatches: 0,
    }
  }
})

// 두 번호 배열 간의 일치하는 번호 개수 계산
function countMatches(numbers1: number[], numbers2: number[]): number {
  return numbers1.filter((num) => numbers2.includes(num)).length
}

// 기본 추천 값 반환 함수 (코드 중복 방지)
function getDefaultRecommendation() {
  return {
    hotNumbers: [1, 7, 12, 23, 34, 45],
    coldNumbers: [3, 11, 19, 27, 33, 42],
    lastUpdated: new Date().toISOString(),
    dataCount: 0,
  }
}

// 번호 빈도수 계산 함수
function calculateNumberFrequency(lottoData: number[][]): Record<number, number> {
  const frequencyMap: Record<number, number> = {}

  // 1부터 45까지의 모든 번호 초기화
  for (let i = 1; i <= 45; i++) {
    frequencyMap[i] = 0
  }

  // 각 회차의 당첨 번호에 대해 빈도수 증가
  for (const draw of lottoData) {
    for (const number of draw) {
      frequencyMap[number]++
    }
  }

  return frequencyMap
}
