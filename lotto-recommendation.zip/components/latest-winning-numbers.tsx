import type { LottoRound } from "@/lib/lotto-api"
import { cn } from "@/lib/utils"

interface LatestWinningNumbersProps {
  latestRound: LottoRound
  hotMatches: number
  coldMatches: number
}

export function LatestWinningNumbers({ latestRound, hotMatches, coldMatches }: LatestWinningNumbersProps) {
  // 번호 색상 결정 함수
  const getNumberColor = (num: number) => {
    if (num <= 10) return "bg-yellow-500"
    if (num <= 20) return "bg-blue-500"
    if (num <= 30) return "bg-red-500"
    if (num <= 40) return "bg-gray-700"
    return "bg-green-500"
  }

  // 날짜 포맷팅
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // 금액 포맷팅
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("ko-KR").format(amount)
  }

  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-2 mb-4">
        <h3 className="text-2xl font-bold text-gray-800">최신 당첨 번호</h3>
        <span className="bg-rose-600 text-white text-sm font-bold px-2 py-1 rounded-full">{latestRound.round}회</span>
      </div>

      <p className="text-gray-600 mb-4">{formatDate(latestRound.drawDate)} 추첨</p>

      <div className="flex justify-center gap-3 mb-4">
        {latestRound.numbers.map((number, index) => (
          <div
            key={index}
            className={cn(
              "w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-xl",
              getNumberColor(number),
            )}
          >
            {number}
          </div>
        ))}
        <div className="flex items-center">
          <span className="mx-2 text-gray-400">+</span>
          <div
            className={cn(
              "w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-xl",
              getNumberColor(latestRound.bonusNumber),
            )}
          >
            {latestRound.bonusNumber}
          </div>
        </div>
      </div>

      {/* HOT/COLD 번호와 일치 정보 */}
      <div className="flex justify-center gap-6 mt-6">
        <div className="text-center">
          <p className="text-sm text-gray-600 mb-1">HOT 번호 일치</p>
          <p className="text-xl font-bold text-rose-600">{hotMatches}개</p>
        </div>
        <div className="text-center">
          <p className="text-sm text-gray-600 mb-1">COLD 번호 일치</p>
          <p className="text-xl font-bold text-blue-600">{coldMatches}개</p>
        </div>
      </div>

      {/* 당첨금 정보 */}
      {latestRound.firstPrizeAmount && latestRound.firstWinnerCount && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg inline-block">
          <p className="text-sm text-gray-600">
            1등 당첨금: <span className="font-bold text-gray-800">{formatAmount(latestRound.firstPrizeAmount)}원</span>
            {latestRound.firstWinnerCount > 1 && (
              <span className="text-gray-500"> (총 {latestRound.firstWinnerCount}명)</span>
            )}
          </p>
        </div>
      )}
    </div>
  )
}
