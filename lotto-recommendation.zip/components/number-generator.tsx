"use client"

import { useState, useEffect } from "react"
import { Shuffle, Save, Trash } from "lucide-react"
import { cn } from "@/lib/utils"

interface NumberGeneratorProps {
  hotNumbers: number[]
  coldNumbers: number[]
}

interface SavedCombination {
  id: string
  numbers: number[]
  timestamp: number
}

export function NumberGenerator({ hotNumbers, coldNumbers }: NumberGeneratorProps) {
  const [generatedNumbers, setGeneratedNumbers] = useState<number[]>([])
  const [savedCombinations, setSavedCombinations] = useState<SavedCombination[]>([])
  const [generationMethod, setGenerationMethod] = useState<"random" | "hot" | "cold" | "mixed">("random")
  const [isGenerating, setIsGenerating] = useState(false)

  // 로컬 스토리지에서 저장된 조합 불러오기
  useEffect(() => {
    const savedData = localStorage.getItem("savedLottoCombinations")
    if (savedData) {
      try {
        setSavedCombinations(JSON.parse(savedData))
      } catch (error) {
        console.error("저장된 조합을 불러오는 중 오류 발생:", error)
      }
    }
  }, [])

  // 저장된 조합이 변경될 때 로컬 스토리지에 저장
  useEffect(() => {
    if (savedCombinations.length > 0) {
      localStorage.setItem("savedLottoCombinations", JSON.stringify(savedCombinations))
    }
  }, [savedCombinations])

  // 번호 생성 함수
  const generateNumbers = () => {
    setIsGenerating(true)

    // 애니메이션 효과를 위한 타임아웃
    setTimeout(() => {
      let pool: number[] = []
      const result: number[] = []

      switch (generationMethod) {
        case "hot":
          // HOT 번호에 가중치 부여 (80% 확률로 HOT 번호에서 선택)
          pool = Array.from({ length: 45 }, (_, i) => i + 1)
          for (let i = 0; i < 6; i++) {
            const useHot = Math.random() < 0.8
            const source = useHot ? hotNumbers : pool.filter((n) => !result.includes(n))
            const availableNumbers = source.filter((n) => !result.includes(n))

            if (availableNumbers.length > 0) {
              const randomIndex = Math.floor(Math.random() * availableNumbers.length)
              result.push(availableNumbers[randomIndex])
            } else {
              // 사용 가능한 번호가 없으면 전체 풀에서 선택
              const remainingNumbers = pool.filter((n) => !result.includes(n))
              const randomIndex = Math.floor(Math.random() * remainingNumbers.length)
              result.push(remainingNumbers[randomIndex])
            }
          }
          break

        case "cold":
          // COLD 번호에 가중치 부여 (80% 확률로 COLD 번호에서 선택)
          pool = Array.from({ length: 45 }, (_, i) => i + 1)
          for (let i = 0; i < 6; i++) {
            const useCold = Math.random() < 0.8
            const source = useCold ? coldNumbers : pool.filter((n) => !result.includes(n))
            const availableNumbers = source.filter((n) => !result.includes(n))

            if (availableNumbers.length > 0) {
              const randomIndex = Math.floor(Math.random() * availableNumbers.length)
              result.push(availableNumbers[randomIndex])
            } else {
              // 사용 가능한 번호가 없으면 전체 풀에서 선택
              const remainingNumbers = pool.filter((n) => !result.includes(n))
              const randomIndex = Math.floor(Math.random() * remainingNumbers.length)
              result.push(remainingNumbers[randomIndex])
            }
          }
          break

        case "mixed":
          // HOT과 COLD 번호를 섞어서 사용
          pool = Array.from({ length: 45 }, (_, i) => i + 1)
          const mixedPool = [...hotNumbers, ...coldNumbers]

          for (let i = 0; i < 6; i++) {
            const useMixed = Math.random() < 0.7
            const source = useMixed ? mixedPool : pool
            const availableNumbers = source.filter((n) => !result.includes(n))

            if (availableNumbers.length > 0) {
              const randomIndex = Math.floor(Math.random() * availableNumbers.length)
              result.push(availableNumbers[randomIndex])
            } else {
              // 사용 가능한 번호가 없으면 전체 풀에서 선택
              const remainingNumbers = pool.filter((n) => !result.includes(n))
              const randomIndex = Math.floor(Math.random() * remainingNumbers.length)
              result.push(remainingNumbers[randomIndex])
            }
          }
          break

        default:
          // 완전 랜덤 생성
          pool = Array.from({ length: 45 }, (_, i) => i + 1)
          while (result.length < 6) {
            const randomIndex = Math.floor(Math.random() * pool.length)
            const number = pool[randomIndex]

            if (!result.includes(number)) {
              result.push(number)
            }
          }
          break
      }

      // 번호 정렬
      result.sort((a, b) => a - b)
      setGeneratedNumbers(result)
      setIsGenerating(false)
    }, 800) // 애니메이션 효과를 위한 딜레이
  }

  // 조합 저장 함수
  const saveCombination = () => {
    if (generatedNumbers.length === 6) {
      const newCombination: SavedCombination = {
        id: Date.now().toString(),
        numbers: [...generatedNumbers],
        timestamp: Date.now(),
      }

      setSavedCombinations((prev) => [newCombination, ...prev])
    }
  }

  // 저장된 조합 삭제 함수
  const deleteCombination = (id: string) => {
    setSavedCombinations((prev) => {
      const updated = prev.filter((comb) => comb.id !== id)

      // 모든 조합이 삭제되면 로컬 스토리지에서도 제거
      if (updated.length === 0) {
        localStorage.removeItem("savedLottoCombinations")
      }

      return updated
    })
  }

  // 번호 색상 결정 함수
  const getNumberColor = (num: number) => {
    if (num <= 10) return "bg-yellow-500"
    if (num <= 20) return "bg-blue-500"
    if (num <= 30) return "bg-red-500"
    if (num <= 40) return "bg-gray-700"
    return "bg-green-500"
  }

  // 날짜 포맷팅 함수
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("ko-KR", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <section className="bg-white p-8 rounded-xl shadow-lg max-w-4xl mx-auto">
      <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">나만의 번호 조합 생성기</h3>

      {/* 생성 방식 선택 */}
      <div className="mb-6">
        <p className="text-gray-700 mb-3 text-center">생성 방식 선택</p>
        <div className="flex flex-wrap justify-center gap-2">
          <button
            onClick={() => setGenerationMethod("random")}
            className={cn(
              "px-4 py-2 rounded-md transition-colors",
              generationMethod === "random" ? "bg-gray-800 text-white" : "bg-gray-100 text-gray-800 hover:bg-gray-200",
            )}
          >
            완전 랜덤
          </button>
          <button
            onClick={() => setGenerationMethod("hot")}
            className={cn(
              "px-4 py-2 rounded-md transition-colors",
              generationMethod === "hot" ? "bg-rose-600 text-white" : "bg-rose-100 text-rose-700 hover:bg-rose-200",
            )}
          >
            HOT 번호 활용
          </button>
          <button
            onClick={() => setGenerationMethod("cold")}
            className={cn(
              "px-4 py-2 rounded-md transition-colors",
              generationMethod === "cold" ? "bg-blue-600 text-white" : "bg-blue-100 text-blue-700 hover:bg-blue-200",
            )}
          >
            COLD 번호 활용
          </button>
          <button
            onClick={() => setGenerationMethod("mixed")}
            className={cn(
              "px-4 py-2 rounded-md transition-colors",
              generationMethod === "mixed"
                ? "bg-purple-600 text-white"
                : "bg-purple-100 text-purple-700 hover:bg-purple-200",
            )}
          >
            혼합 번호 활용
          </button>
        </div>
      </div>

      {/* 번호 생성 버튼 */}
      <div className="flex justify-center mb-8">
        <button
          onClick={generateNumbers}
          disabled={isGenerating}
          className="flex items-center gap-2 px-6 py-3 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors disabled:opacity-70"
        >
          <Shuffle size={20} />
          {isGenerating ? "생성 중..." : "번호 생성하기"}
        </button>
      </div>

      {/* 생성된 번호 표시 */}
      <div className="mb-8">
        <div className="flex justify-center gap-3 mb-4">
          {isGenerating
            ? // 로딩 애니메이션
              Array.from({ length: 6 }).map((_, index) => (
                <div
                  key={index}
                  className="w-12 h-12 rounded-full bg-gray-200 animate-pulse flex items-center justify-center"
                ></div>
              ))
            : generatedNumbers.length > 0
              ? // 생성된 번호
                generatedNumbers.map((number, index) => (
                  <div
                    key={index}
                    className={`${getNumberColor(
                      number,
                    )} w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg`}
                  >
                    {number}
                  </div>
                ))
              : // 빈 상태
                Array.from({ length: 6 }).map((_, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400"
                  >
                    ?
                  </div>
                ))}
        </div>

        {/* 저장 버튼 */}
        {generatedNumbers.length > 0 && !isGenerating && (
          <div className="flex justify-center">
            <button
              onClick={saveCombination}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors"
            >
              <Save size={16} />
              조합 저장하기
            </button>
          </div>
        )}
      </div>

      {/* 저장된 조합 목록 */}
      {savedCombinations.length > 0 && (
        <div>
          <h4 className="text-lg font-semibold text-gray-800 mb-3">저장된 번호 조합</h4>
          <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
            {savedCombinations.map((combination) => (
              <div key={combination.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">{formatDate(combination.timestamp)}</span>
                  <div className="flex gap-1">
                    {combination.numbers.map((number, index) => (
                      <div
                        key={index}
                        className={`${getNumberColor(
                          number,
                        )} w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs`}
                      >
                        {number}
                      </div>
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => deleteCombination(combination.id)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                  aria-label="삭제"
                >
                  <Trash size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  )
}
