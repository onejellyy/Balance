"use client"

import { useState, useEffect } from "react"
import { AlertCircle } from "lucide-react"

export function AdBlockerNotice() {
  const [isAdBlockerDetected, setIsAdBlockerDetected] = useState(false)
  const [isDismissed, setIsDismissed] = useState(false)

  useEffect(() => {
    // 광고 차단기 감지 로직
    const detectAdBlocker = async () => {
      try {
        // 간단한 광고 차단기 감지 방법
        const testAd = document.createElement("div")
        testAd.innerHTML = "&nbsp;"
        testAd.className = "adsbox"
        document.body.appendChild(testAd)

        // 약간의 지연 후 확인
        await new Promise((resolve) => setTimeout(resolve, 100))

        // 광고 차단기가 활성화되어 있으면 요소가 숨겨짐
        const isBlocked = testAd.offsetHeight === 0

        // 테스트 요소 제거
        document.body.removeChild(testAd)

        // 로컬 스토리지에서 이전에 알림을 닫았는지 확인
        const dismissed = localStorage.getItem("adBlockerNoticeDismissed") === "true"

        setIsAdBlockerDetected(isBlocked)
        setIsDismissed(dismissed)
      } catch (error) {
        console.error("광고 차단기 감지 중 오류 발생:", error)
      }
    }

    detectAdBlocker()
  }, [])

  const dismissNotice = () => {
    localStorage.setItem("adBlockerNoticeDismissed", "true")
    setIsDismissed(true)
  }

  if (!isAdBlockerDetected || isDismissed) {
    return null
  }

  return (
    <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-8 rounded-md">
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <AlertCircle className="h-5 w-5 text-amber-400" />
        </div>
        <div className="ml-3">
          <p className="text-sm text-amber-700">
            광고 차단 기능이 활성화되어 있습니다. 이 사이트는 광고 수익으로 운영됩니다. 서비스 이용을 위해 광고 차단을
            해제해 주시면 감사하겠습니다.
          </p>
          <div className="mt-2">
            <button
              onClick={dismissNotice}
              className="text-sm text-amber-700 font-medium underline hover:text-amber-800"
            >
              다시 보지 않기
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
