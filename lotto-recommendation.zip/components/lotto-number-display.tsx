"use client"

import { useState } from "react"
import { Copy } from "lucide-react"
import { cn } from "@/lib/utils"

interface LottoNumberDisplayProps {
  numbers: number[]
  type: "hot" | "cold"
}

export function LottoNumberDisplay({ numbers, type }: LottoNumberDisplayProps) {
  const [copied, setCopied] = useState(false)

  const copyToClipboard = () => {
    navigator.clipboard.writeText(numbers.join(", "))
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const getNumberColor = (num: number) => {
    if (num <= 10) return "bg-yellow-500"
    if (num <= 20) return "bg-blue-500"
    if (num <= 30) return "bg-red-500"
    if (num <= 40) return "bg-gray-700"
    return "bg-green-500"
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-center gap-2">
        {numbers.map((number, index) => (
          <div
            key={index}
            className={cn(
              "w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg",
              getNumberColor(number),
            )}
          >
            {number}
          </div>
        ))}
      </div>

      <button
        onClick={copyToClipboard}
        className={cn(
          "flex items-center justify-center gap-2 mx-auto px-4 py-2 rounded-md transition-colors",
          type === "hot"
            ? "bg-rose-100 text-rose-700 hover:bg-rose-200"
            : "bg-blue-100 text-blue-700 hover:bg-blue-200",
        )}
      >
        <Copy size={16} />
        {copied ? "복사됨!" : "번호 복사하기"}
      </button>
    </div>
  )
}
