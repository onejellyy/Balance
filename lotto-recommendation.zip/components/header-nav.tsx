"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export function HeaderNav() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "홈" },
    // 관리자만 접근 가능한 데이터 페이지는 표시하지 않음
  ]

  return (
    <nav className="flex space-x-4">
      {navItems.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={cn(
            "px-3 py-1 rounded-md text-sm font-medium transition-colors",
            pathname === item.href ? "bg-rose-100 text-rose-700" : "text-gray-700 hover:bg-rose-50 hover:text-rose-600",
          )}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  )
}
