"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { useInView } from "react-intersection-observer"

interface AdUnitProps {
  slot: string
  format?: "auto" | "horizontal" | "vertical" | "rectangle" | "fluid"
  responsive?: boolean
  className?: string
  style?: React.CSSProperties
  lazyLoad?: boolean
  label?: string
}

export function AdUnit({
  slot,
  format = "auto",
  responsive = true,
  className = "",
  style = {},
  lazyLoad = true,
  label = "광고",
}: AdUnitProps) {
  const [isClient, setIsClient] = useState(false)
  const adRef = useRef<HTMLDivElement>(null)
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    // 컴포넌트가 뷰포트에 들어왔고, 클라이언트 사이드일 때만 실행
    if ((inView || !lazyLoad) && isClient && adRef.current) {
      try {
        // 광고 초기화 (window.adsbygoogle가 정의되어 있는지 확인)
        if (window.adsbygoogle) {
          ;(window.adsbygoogle = window.adsbygoogle || []).push({})
        } else {
          console.warn("adsbygoogle is not defined. 애드센스 스크립트가 로드되지 않았습니다.")
        }
      } catch (error) {
        console.error("애드센스 광고 초기화 중 오류 발생:", error)
      }
    }
  }, [inView, isClient, lazyLoad])

  // 서버 사이드 렌더링 또는 클라이언트 사이드 초기 렌더링 시 플레이스홀더 반환
  if (!isClient) {
    return (
      <div
        className={`ad-container flex justify-center items-center ${className}`}
        style={{
          ...style,
          minHeight: format === "horizontal" ? "90px" : format === "rectangle" ? "250px" : "100px",
        }}
      />
    )
  }

  return (
    <div
      ref={ref}
      className={`ad-container flex justify-center items-center ${className}`}
      style={style}
      data-ad-format={format}
    >
      {label && <span className="ad-label">{label}</span>}
      {(inView || !lazyLoad) && (
        <div ref={adRef} className="w-full h-full flex justify-center items-center">
          <ins
            className="adsbygoogle"
            style={{
              display: "block",
              textAlign: "center",
              width: "100%",
              height: format === "rectangle" ? "250px" : "100%",
              ...style,
            }}
            data-ad-client="ca-pub-7094140389853787"
            data-ad-slot={slot}
            data-ad-format={format}
            data-full-width-responsive={responsive ? "true" : "false"}
          />
        </div>
      )}
    </div>
  )
}

// 전역 타입 선언 (window.adsbygoogle)
declare global {
  interface Window {
    adsbygoogle: any[]
  }
}
