"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { LottoRound } from "@/lib/lotto-api"
import { AdUnit } from "@/components/ad-unit"
import Link from "next/link"

export default function LottoDataPage() {
  const [lottoData, setLottoData] = useState<LottoRound[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [startRound, setStartRound] = useState(1)
  const [endRound, setEndRound] = useState(1171)
  const [currentPage, setCurrentPage] = useState(1)
  const [isAdmin, setIsAdmin] = useState(false) // 관리자 상태 추가
  const itemsPerPage = 10

  // 관리자 확인 (간단한 예시 - 실제로는 더 안전한 인증 방식 사용)
  useEffect(() => {
    const checkAdmin = () => {
      const adminCode = localStorage.getItem("adminCode")
      const isAdminUser = adminCode === "lotto-admin-2024"
      setIsAdmin(isAdminUser)

      // 관리자가 아니면 데이터를 로드하지 않음
      if (isAdminUser) {
        loadData()
      } else {
        setLoading(false)
      }
    }

    checkAdmin()
  }, [])

  // 데이터 로드 함수
  const loadData = async () => {
    try {
      setLoading(true)
      setError(null)

      // API 요청 시 타임아웃 설정
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 30000) // 30초 타임아웃

      const response = await fetch(`/api/lotto-data?start=${startRound}&end=${endRound}`, {
        signal: controller.signal,
      })

      clearTimeout(timeoutId) // 타임아웃 해제

      if (!response.ok) {
        throw new Error(`서버 오류: ${response.status} ${response.statusText}`)
      }

      // 응답이 JSON인지 확인
      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error("서버에서 유효한 JSON 응답을 받지 못했습니다.")
      }

      const result = await response.json()

      if (result.success) {
        setLottoData(result.data || [])
      } else {
        throw new Error(result.error || "데이터를 불러오는데 실패했습니다.")
      }
    } catch (err: any) {
      console.error("로또 데이터 로드 오류:", err)

      // 오류 메시지 개선
      if (err.name === "AbortError") {
        setError("요청 시간이 초과되었습니다. 나중에 다시 시도해 주세요.")
      } else if (err.message.includes("JSON")) {
        setError("서버 응답을 처리할 수 없습니다. API 서버가 올바르게 설정되었는지 확인해 주세요.")
      } else {
        setError(err.message || "데이터를 불러오는데 실패했습니다.")
      }
    } finally {
      setLoading(false)
    }
  }

  // 검색 핸들러
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setCurrentPage(1)
    loadData()
  }

  // 페이지네이션 계산
  const totalPages = Math.ceil(lottoData.length / itemsPerPage)
  const currentData = lottoData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  // 번호 색상 결정 함수
  const getNumberColor = (num: number) => {
    if (num <= 10) return "bg-yellow-500"
    if (num <= 20) return "bg-blue-500"
    if (num <= 30) return "bg-red-500"
    if (num <= 40) return "bg-gray-700"
    return "bg-green-500"
  }

  // 관리자가 아닌 경우 접근 제한 메시지 표시
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-rose-50 to-rose-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-xl shadow-lg max-w-md mx-auto text-center">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">관리자 전용 페이지</h1>
            <p className="text-gray-600 mb-6">
              이 페이지는 관리자만 접근할 수 있습니다. 홈페이지로 돌아가 로또 번호 추천 서비스를 이용해 주세요.
            </p>
            <Link
              href="/"
              className="inline-block px-4 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700 transition-colors"
            >
              홈페이지로 돌아가기
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-rose-100 py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-800 mb-8 text-center">로또 당첨 번호 데이터 (관리자용)</h1>

        {/* 검색 폼 */}
        <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
          <form onSubmit={handleSearch} className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <label htmlFor="startRound" className="block text-sm font-medium text-gray-700 mb-1">
                시작 회차
              </label>
              <input
                type="number"
                id="startRound"
                min="1"
                max={endRound}
                value={startRound}
                onChange={(e) => setStartRound(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>

            <div className="flex-1 min-w-[200px]">
              <label htmlFor="endRound" className="block text-sm font-medium text-gray-700 mb-1">
                종료 회차
              </label>
              <input
                type="number"
                id="endRound"
                min={startRound}
                max={1171} // 안전한 최대값으로 제한
                value={endRound}
                onChange={(e) => setEndRound(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>

            <div className="flex items-end w-full sm:w-auto">
              <button
                type="submit"
                className="w-full sm:w-auto px-4 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700 transition-colors"
                disabled={loading}
              >
                {loading ? "검색 중..." : "검색"}
              </button>
            </div>
          </form>
        </div>

        {/* 광고 */}
        <div className="my-6 flex justify-center">
          <AdUnit slot="1234567890" format="horizontal" className="w-full max-w-4xl" label="sponsored" />
        </div>

        {/* 데이터 표시 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-rose-600 mb-2"></div>
              <p>데이터를 불러오는 중입니다...</p>
            </div>
          ) : error ? (
            <div className="p-8 text-center text-red-600">
              <p>{error}</p>
              <button
                onClick={loadData}
                className="mt-4 px-4 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700 transition-colors"
                disabled={loading}
              >
                다시 시도
              </button>
            </div>
          ) : lottoData.length === 0 ? (
            <div className="p-8 text-center text-gray-600">
              <p>데이터가 없습니다.</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        회차
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        추첨일
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        당첨 번호
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        보너스
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {currentData.map((round) => (
                      <tr key={round.round} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {round.round}회
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(round.drawDate).toLocaleDateString("ko-KR")}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-1">
                            {round.numbers.map((num) => (
                              <div
                                key={num}
                                className={`${getNumberColor(num)} w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold`}
                              >
                                {num}
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div
                            className={`${getNumberColor(round.bonusNumber)} w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold`}
                          >
                            {round.bonusNumber}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* 페이지네이션 */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between items-center flex-wrap gap-4">
                <div className="text-sm text-gray-700">
                  총 <span className="font-medium">{lottoData.length}</span>개 결과 중{" "}
                  <span className="font-medium">{lottoData.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}</span>
                  -<span className="font-medium">{Math.min(currentPage * itemsPerPage, lottoData.length)}</span>
                </div>

                <div className="flex space-x-2">
                  <button
                    onClick={() => setCurrentPage(1)}
                    disabled={currentPage === 1 || totalPages === 0}
                    className="px-3 py-1 border rounded-md text-sm disabled:opacity-50"
                  >
                    처음
                  </button>
                  <button
                    onClick={() => setCurrentPage(currentPage - 1)}
                    disabled={currentPage === 1 || totalPages === 0}
                    className="px-3 py-1 border rounded-md text-sm disabled:opacity-50"
                  >
                    이전
                  </button>
                  <span className="px-3 py-1 text-sm">
                    {totalPages > 0 ? `${currentPage} / ${totalPages}` : "0 / 0"}
                  </span>
                  <button
                    onClick={() => setCurrentPage(currentPage + 1)}
                    disabled={currentPage === totalPages || totalPages === 0}
                    className="px-3 py-1 border rounded-md text-sm disabled:opacity-50"
                  >
                    다음
                  </button>
                  <button
                    onClick={() => setCurrentPage(totalPages)}
                    disabled={currentPage === totalPages || totalPages === 0}
                    className="px-3 py-1 border rounded-md text-sm disabled:opacity-50"
                  >
                    마지막
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* 광고 */}
        <div className="mt-8 flex justify-center">
          <AdUnit slot="2345678901" format="rectangle" className="w-full max-w-md" label="sponsored" />
        </div>
      </div>
    </div>
  )
}
