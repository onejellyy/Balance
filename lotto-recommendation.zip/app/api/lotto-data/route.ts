import { NextResponse } from "next/server"
import { fetchLottoDataRange } from "@/lib/lotto-api"

// 로또 데이터를 가져오는 API 라우트
export async function GET(request: Request) {
  try {
    // URL에서 쿼리 파라미터 추출
    const { searchParams } = new URL(request.url)
    const startRound = searchParams.get("start") ? Number.parseInt(searchParams.get("start")!) : 1
    const endRound = searchParams.get("end") ? Number.parseInt(searchParams.get("end")!) : 1171

    // 안전한 최대 회차
    const SAFE_MAX_ROUND = 1171

    // 유효한 범위로 제한
    const validStartRound = Math.max(1, Math.min(startRound, SAFE_MAX_ROUND))
    const validEndRound = Math.max(validStartRound, Math.min(endRound, SAFE_MAX_ROUND))

    console.log(`API 요청: ${validStartRound}회차부터 ${validEndRound}회차까지 데이터 가져오기`)

    // 데이터 가져오기
    const lottoData = await fetchLottoDataRange(validStartRound, validEndRound)

    return NextResponse.json({
      success: true,
      count: lottoData.length,
      data: lottoData,
    })
  } catch (error) {
    console.error("로또 데이터 API 오류:", error)
    return NextResponse.json(
      { success: false, error: "로또 데이터를 가져오는 중 오류가 발생했습니다." },
      { status: 500 },
    )
  }
}
