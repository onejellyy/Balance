import { LottoNumberDisplay } from "@/components/lotto-number-display"
import { NumberGenerator } from "@/components/number-generator"
import { AdUnit } from "@/components/ad-unit"
import { AdBlockerNotice } from "@/components/ad-blocker-notice"
import { LottoStructuredData } from "@/components/structured-data"
import { getLottoRecommendationsEnhanced } from "@/lib/lotto-service-enhanced"
import { formatDistanceToNow } from "date-fns"
import { ko } from "date-fns/locale"
import { HeaderNav } from "@/components/header-nav"
import { LatestWinningNumbers } from "@/components/latest-winning-numbers"

export default async function Home() {
  // 최신 회차부터 100개 회차 데이터를 참조해서 hot/cold 번호 계산
  const { hotNumbers, coldNumbers, lastUpdated, dataCount, latestRound, hotMatches, coldMatches } =
    await getLottoRecommendationsEnhanced()

  // 마지막 업데이트 시간 포맷팅
  const lastUpdatedFormatted = formatDistanceToNow(new Date(lastUpdated), {
    addSuffix: true,
    locale: ko,
  })

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-rose-100">
      {/* 구조화된 데이터 추가 */}
      <LottoStructuredData />

      <header className="container mx-auto py-6 px-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-rose-600">로또 번호 추천</h1>
          <HeaderNav />
        </div>
      </header>

      <main className="container mx-auto py-12 px-4">
        {/* 광고 차단기 감지 알림 */}
        <AdBlockerNotice />

        {/* 최신 회차 당첨 번호 표시 */}
        {latestRound && (
          <section className="bg-white p-6 rounded-xl shadow-lg mb-8">
            <LatestWinningNumbers latestRound={latestRound} hotMatches={hotMatches} coldMatches={coldMatches} />
          </section>
        )}

        <section className="text-center mb-8">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">당첨 확률을 높이는 번호 추천</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            동행복권의 당첨 통계 데이터를 분석하여 가장 효과적인 번호 조합을 추천해 드립니다.
          </p>
          <p className="text-sm text-gray-500 mt-4">
            {dataCount > 0
              ? `최근 ${dataCount}회차 데이터 기준 · ${lastUpdatedFormatted} 업데이트`
              : "데이터 로딩 중..."}
          </p>
        </section>

        {/* 첫 번째 광고: 콘텐츠 시작 전 */}
        <div className="mb-10 mt-2 flex justify-center">
          <AdUnit slot="1234567890" format="horizontal" className="w-full max-w-4xl" label="sponsored" />
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-2xl font-bold text-rose-600 mb-4">HOT 번호 조합</h3>
            <p className="text-gray-600 mb-6">가장 자주 등장한 번호들로 구성된 조합입니다.</p>
            <LottoNumberDisplay numbers={hotNumbers} type="hot" />
            {latestRound && (
              <p className="mt-4 text-center text-sm font-medium">
                최신 회차와 <span className="text-rose-600">{hotMatches}개</span> 일치
              </p>
            )}
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-2xl font-bold text-blue-600 mb-4">COLD 번호 조합</h3>
            <p className="text-gray-600 mb-6">가장 적게 등장한 번호들로 구성된 조합입니다.</p>
            <LottoNumberDisplay numbers={coldNumbers} type="cold" />
            {latestRound && (
              <p className="mt-4 text-center text-sm font-medium">
                최신 회차와 <span className="text-blue-600">{coldMatches}개</span> 일치
              </p>
            )}
          </div>
        </div>

        {/* 두 번째 광고: 콘텐츠 섹션 사이 */}
        <div className="my-10 flex justify-center">
          <AdUnit slot="2345678901" format="rectangle" className="w-full max-w-md" label="sponsored" />
        </div>

        {/* 번호 생성기 섹션 */}
        <NumberGenerator hotNumbers={hotNumbers} coldNumbers={coldNumbers} />

        {/* 세 번째 광고: 콘텐츠 끝 */}
        <div className="mt-16 mb-4 flex justify-center">
          <AdUnit slot="3456789012" format="auto" className="w-full max-w-4xl" label="sponsored" />
        </div>
      </main>

      <footer className="container mx-auto py-8 px-4 border-t border-rose-200">
        <p className="text-center text-gray-600 mb-4">
          © {new Date().getFullYear()} 로또 번호 추천 서비스. 이 서비스는 참고용으로만 사용하시기 바랍니다.
        </p>

        {/* 네 번째 광고: 푸터 내 */}
        <div className="mt-4 flex justify-center">
          <AdUnit slot="4567890123" format="horizontal" className="w-full max-w-3xl" label="sponsored" />
        </div>
      </footer>
    </div>
  )
}
